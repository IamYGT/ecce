<?php require("include/baglan.php"); include("include/fonksiyon.php"); include_once("inc.lang.php"); ?>
<!DOCTYPE html>
<html lang="tr">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Byasi - Architecture & Interior HTML Template</title>
      <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
      <!-- css include -->
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/all.min.css">
      <link rel="stylesheet" href="assets/css/flipclock.css">
      <link rel="stylesheet" href="assets/css/animate.css">
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/responsive.css">
   </head>
   <body>
     
      <!-- body wrap start -->
      <div class="body_wrap">
         <!-- Header Start -->
         <header class="header">
            <div class="row">
               <div class="col-lg-12">
                  <div class="header-inn">
                     <div class="site-logo">
                        <a href="index.html"><img src="assets/img/logo.png" alt="logo" /></a>
                     </div>
                     <div class="header-navigation">
                        <div class="mainmenu">
                           <nav id="menu">
                              <ul class="dropdown">
                                 <li><a href="index.html">Home</a></li>
                                 <li><a href="about.html">About</a></li>
                                 <li>
                                    <a href="javascript:;">Projects</a>
                                    <ul>
                                       <li><a href="project.html">Project</a></li>
                                       <li><a href="project-details.html">Project Details</a></li>
                                    </ul>
                                 </li>
                                 <li>
                                    <a href="javascript:;">Service</a>
                                    <ul>
                                       <li><a href="service.html">Service</a></li>
                                       <li><a href="service-details.html">Service Details</a></li>
                                    </ul>
                                 </li>
                                 <li>
                                    <a href="javascript:;">Pages</a>
                                    <ul>
                                       <li><a href="portfolio.html">Portfolio</a></li>
                                       <li><a href="team.html">Team</a></li>
                                       <li><a href="faq.html">Faq</a></li>
                                       <li><a href="contact.html">Contact</a></li>
                                       <li><a href="404.html">Error</a></li>
                                       <li><a href="comming-soon.html">Coming Soon</a></li>
                                    </ul>
                                 </li>
                                 <li>
                                    <a href="javascript:;">Blog</a>
                                    <ul>
                                       <li><a href="blog.html">Blog</a></li>
                                       <li><a href="blog-details.html">Blog Details</a></li>
                                    </ul>
                                 </li>
                                 <li><a href="contact.html">Contact</a></li>
                              </ul>
                           </nav>
                        </div>
                        <div class="header-action">
                           <a href="javascript:;" class="search-toggle"><i class="fa fa-search"></i></a>
                           <a href="contact.html" class="header-btn">
                              <div class="icon-holder"><i class="far fa-envelope"></i></div>
                              Get In Touch
                           </a>
                        </div>
                        <div id="search-overlay" class="block">
                           <div class="centered">
                              <div id='search-box'>
                                 <i id="close-btn" class="fa fa-times fa-2x"></i>
                                 <form action='/search' id='search-form' method='get' target='_top'>
                                    <input id='search-text' name='q' placeholder='Type here...' type='text' />
                                    <button id='search-button' type='submit'>
                                    <i class="fa fa-search"></i>
                                    </button>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <div class="spinner-master">
                           <div id="spinner-form" class="spinner-spin">
                              <div class="spinner diagonal part-1"></div>
                              <div class="spinner horizontal"></div>
                              <div class="spinner diagonal part-2"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <!-- Header End -->
         <!-- breadcrumb start -->
         <section class="breadcrumb-area jarallax" data-background="assets/img/breadcrumb-bg.jpg">
            <div class="hero-social">
               <ul>
                  <li><a href="javascript:;"><i class="fab fa-pinterest-p"></i></a></li>
                  <li><a href="javascript:;"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="javascript:;"><i class="fab fa-instagram"></i></a></li>
                  <li><a href="javascript:;"><i class="fab fa-twitter"></i></a></li>
               </ul>
               <p>Follow Us</p>
            </div>
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="breadcrumb-inn wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
                        <h1>Error</h1>
                        <ul>
                           <li class="home"><a href="index.html"><span class="fas fa-home"></span></a></li>
                           <li>404 Notfound</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- breadcrumb end -->
         <!-- Error Page start-->
         <section class="error-page-area">
            <div class="container">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="error-page-inn text-center">
                        <h2>4<span><i class="far fa-frown"></i></span>4</h2>
                        <h3>Sorry, We can’t find anything.</h3>
                        <p>But don’t be afraid. Just click on go home btn.</p>
                        <a href="index.html" class="cta-btn btn-fill">Go To Home</a>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- Error Page End-->
         <!-- footer start -->
         <footer class="footer-area">
            <div class="footer-top">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-4 col-sm-6 order-lg-1 order-1">
                        <div class="single-footer">
                           <h3>About</h3>
                           <p>Precious ipsum dolor sit amet consectetur<br> adipisicing elit, sed dos mod tempor</p>
                           <ul class="footer-contact">
                              <li><i class="fas fa-phone-square-alt"></i> (444) 123 4567 89</li>
                              <li><i class="fas fa-envelope"></i> support@company.com</li>
                              <li><i class="fas fa-map"></i> 74 South Doult Street, Dubai.</li>
                           </ul>
                        </div>
                     </div>
                     <div class="col-lg-2 col-sm-6 order-lg-2 order-3">
                        <div class="single-footer">
                           <h3>Qucik Links</h3>
                           <ul>
                              <li><a href="javascript:;">About Us</a></li>
                              <li><a href="javascript:;">Our Projects</a></li>
                              <li><a href="javascript:;">Our Services</a></li>
                              <li><a href="javascript:;">Meet The Team</a></li>
                              <li><a href="javascript:;">Contact</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="col-lg-2 col-sm-6 order-lg-3 order-4">
                        <div class="single-footer">
                           <h3>Exlore</h3>
                           <ul>
                              <li><a href="javascript:;">Case Study</a></li>
                              <li><a href="javascript:;">Latest News</a></li>
                              <li><a href="javascript:;">Help Center</a></li>
                              <li><a href="javascript:;">Privacy Policy</a></li>
                              <li><a href="javascript:;">Terms & Condition</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 order-lg-4 order-2">
                        <div class="single-footer">
                           <h3>Newsletter</h3>
                           <p>Sign up now for weekly news & updates.</p>
                           <div class="newsletter_form">
                              <form>
                                 <input type="email" placeholder="Email Address" />
                                 <button type="submit"><i class="fas fa-long-arrow-alt-right"></i></button>
                              </form>
                           </div>
                           <ul class="footer-social">
                              <li><a href="javascript:;"><i class="fab fa-pinterest-p"></i></a></li>
                              <li><a href="javascript:;"><i class="fab fa-facebook-f"></i></a></li>
                              <li><a href="javascript:;"><i class="fab fa-instagram"></i></a></li>
                              <li><a href="javascript:;"><i class="fab fa-twitter"></i></a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="container">
               <div class="fade_rule"></div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12">
                        <p>&copy; Copyright 2021 by Themescare</p>
                     </div>
                  </div>
               </div>
            </div>
         </footer>
         <!-- footer end -->
      </div>
      <!-- body wrap end -->
      
      
      <!-- jquery include -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="assets/js/owl.carousel.min.js"></script>
      <script src="assets/js/jquery.barfiller.js"></script>
      <script src="assets/js/flipclock.min.js"></script>
      <script src="assets/js/jarallax.min.js"></script>
      <script src="assets/js/custom-countdown.js"></script>
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <script src="assets/js/jquery.counterup.min.js"></script>
      <script src="assets/js/waypoints-min.js"></script>
      <script src="assets/js/wow.min.js"></script>
      <script src="assets/js/main.js"></script>
   </body>
</html>